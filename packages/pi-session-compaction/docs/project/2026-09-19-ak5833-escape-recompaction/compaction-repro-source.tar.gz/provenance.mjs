import { createHash, randomUUID } from 'node:crypto';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const digest = file => createHash('sha256').update(readFileSync(file)).digest('hex');
const ref = root => execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
function tree(root, subdir) {
  return Object.fromEntries(readdirSync(path.join(root, subdir), { recursive: true })
    .filter(name => /\.(js|mjs|md)$/.test(name)).sort()
    .map(name => [path.join(subdir, name), digest(path.join(root, subdir, name))]));
}
export function provenance(host, actualRoot) {
  const result = {
    hostRef: ref(host), node: process.version,
    fixture: Object.fromEntries(['probe.mjs', 'minimal-hook.mjs', 'tui-driver.mjs', 'provenance.mjs', 'verify.mjs', 'run-matrix.sh']
      .map(name => [name, digest(path.join(here, name))])),
    hostBuilds: Object.fromEntries(['coding-agent', 'agent', 'ai', 'tui'].map(pkg => [pkg, tree(host, `packages/${pkg}/dist`)])),
  };
  if (actualRoot) result.customHook = {
    repoRef: ref(actualRoot), files: tree(actualRoot, 'extensions'),
    config: existsSync(path.join(actualRoot, 'extensions/session-compaction/config.json'))
      ? digest(path.join(actualRoot, 'extensions/session-compaction/config.json')) : 'absent: package defaults',
    modelSelection: tree(path.resolve(actualRoot, '../pi-model-selection'), 'src'),
  };
  return result;
}
export const newRunId = () => `AK5833-${randomUUID()}`;
