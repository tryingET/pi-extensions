#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
: "${PI_REPRO_HOST:?Set PI_REPRO_HOST to the built 4d38031fb checkout}"
: "${TMPDIR:?Set TMPDIR to your scratch directory}"
if [[ -e "$ROOT/evidence" ]]; then
  echo 'Refusing to overwrite evidence; move the previous evidence directory first.' >&2
  exit 1
fi
mkdir -p "$ROOT/evidence"
SCRATCH=$(mktemp -d "$TMPDIR/ak5833.XXXXXX")
printf '%s\n' "$SCRATCH" > "$ROOT/scratch-path"
mkdir -p "$SCRATCH/home" "$SCRATCH/agent"
HOOKS=(minimal)
if [[ -n "${PI_REPRO_COMPACTION:-}" ]]; then HOOKS+=(actual); fi
for HOOK in "${HOOKS[@]}"; do
  for KEEP in 0 1; do
    for CANCEL in attempt run; do
      OUT="$ROOT/evidence/$HOOK-$CANCEL-$KEEP"
      (
        cd "$SCRATCH"
        unshare --user --map-root-user --net env -i PATH="$PATH" HOME="$SCRATCH/home" \
          TMPDIR="$SCRATCH" PI_CODING_AGENT_DIR="$SCRATCH/agent" PI_OFFLINE=1 \
          PI_REPRO_HOST="$PI_REPRO_HOST" PI_REPRO_COMPACTION="${PI_REPRO_COMPACTION:-}" \
          EVIDENCE_DIR="$OUT" HOOK="$HOOK" KEEP="$KEEP" CANCEL="$CANCEL" \
          node "$ROOT/probe.mjs"
      )
    done
    HOOK="$HOOK" KEEP="$KEEP" node "$ROOT/tui-driver.mjs"
  done
done
node "$ROOT/verify.mjs" "$ROOT/evidence"
