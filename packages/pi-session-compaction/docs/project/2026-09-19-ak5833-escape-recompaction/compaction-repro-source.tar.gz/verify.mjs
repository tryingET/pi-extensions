import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
export function verifyEvidence(dir) {
  const read = name => JSON.parse(readFileSync(path.join(dir, name), 'utf8'));
  const result = read('result.json');
  const events = read('events.json');
  const provenance = read('provenance.json');
  const stream = readFileSync(path.join(dir, 'events.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
  assert.deepEqual(stream, events);
  assert(events.every((e, i) => e.seq === i && e.runId === result.runId));
  assert.equal(result.runId, provenance.runId);
  assert.equal(provenance.hostRef, '4d38031fbdbed43bc481ddf9c3c279005ab24674');
  const byType = type => events.filter(e => e.type === type);
  const fullAbort = result.cancellation === 'run';
  const expectedAttempts = fullAbort ? 1 : 2;
  assert.equal(result.attempts, expectedAttempts);
  assert.equal(result.summaries, expectedAttempts);
  assert.equal(result.answers, fullAbort ? 0 : 1);
  assert.equal(result.compactionEntries, 0);
  assert.equal(result.hookFailures.length, 0);
  assert.equal(result.forbiddenFetches, 0);
  assert.equal(result.idle, true);
  assert.equal(result.autoCompactionEnabled, true);
  const starts = byType('compaction_start');
  const ends = byType('compaction_end');
  assert.equal(starts.length, expectedAttempts);
  assert.equal(ends.length, expectedAttempts);
  assert(ends.every(e => e.aborted === true));
  assert(starts.every(e => e.reason === 'threshold'));
  assert.equal(byType('agent_settled').length, 1);
  assert(byType('tool_execution_end')[0].seq < starts[0].seq);
  assert(starts[0].seq < byType('agent_end')[0].seq, 'first attempt must be between turns');
  for (let i = 0; i < expectedAttempts; i++) {
    const attempt = i + 1;
    const inside = (type) => byType(type).filter(e => e.seq > starts[i].seq && e.seq < ends[i].seq);
    const start = inside('custom_hook_start');
    const stop = inside('custom_hook_end');
    const requests = inside('summary_request');
    const aborts = inside('summary_aborted');
    const cancels = inside(result.cancellation === 'escape' ? 'stdin_escape' : 'cancel_requested');
    for (const group of [start, stop, requests, aborts, cancels]) {
      assert.equal(group.length, 1, `${typeDescription(result)} attempt ${attempt} multiplicity`);
      assert.equal(group[0].attempt, attempt);
    }
    assert.equal(start[0].keep, result.keepRecentTokens);
    assert.equal(start[0].historyMessages, 0, 'not parallel history/prefix summarization');
    assert.equal(stop[0].cancel, true);
    assert.equal(stop[0].summary, false);
    assert(start[0].seq < requests[0].seq && requests[0].seq < cancels[0].seq);
    assert(cancels[0].seq < aborts[0].seq && aborts[0].seq < stop[0].seq);
  }
  if (!fullAbort) {
    assert.equal(result.assistantErrors.length, 0);
    assert(ends[0].seq < byType('answer_request')[0].seq);
    assert(byType('answer_request')[0].seq < byType('agent_end')[0].seq);
    assert(byType('agent_end')[0].seq < starts[1].seq, 'second attempt after low-level agent_end');
  }
  assert(ends.at(-1).seq < byType('agent_settled')[0].seq);
  if (result.cancellation === 'escape') {
    assert.equal(result.escapes, expectedAttempts);
    const driver = readFileSync(path.join(dir, 'driver.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
    assert.deepEqual(driver.map(e => e.attempt), [1, 2]);
    assert(driver.every(e => events[e.afterSeq].type === 'summary_request'));
  }
  return result;
}
function typeDescription(r) { return `${r.hook}/${r.cancellation}/${r.keepRecentTokens}`; }
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const root = process.argv[2];
  assert(root, 'Usage: node verify.mjs <evidence-root>');
  for (const name of readdirSync(root)) {
    const result = verifyEvidence(path.join(root, name));
    console.log(`PASS ${typeDescription(result)}: attempts=${result.attempts}, answers=${result.answers}`);
  }
}
