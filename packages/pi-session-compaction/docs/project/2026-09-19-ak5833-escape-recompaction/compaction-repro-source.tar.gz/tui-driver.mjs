// Real PTY input driver: sends one Escape per observed compaction summary attempt.
import assert from 'node:assert/strict';
import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { verifyEvidence } from './verify.mjs';
const root = path.dirname(fileURLToPath(import.meta.url));
const scratch = readFileSync(`${root}/scratch-path`, 'utf8').trim();
const hook = process.env.HOOK ?? 'minimal';
const keep = process.env.KEEP ?? '0';
const out = path.join(root, 'evidence', `${hook}-escape-${keep}`);
assert(!existsSync(out), 'Refusing to overwrite an earlier PTY run');
mkdirSync(out, { recursive: true });
writeFileSync(`${out}/driver.jsonl`, '');
writeFileSync(`${out}/stdout.log`, '');
const env = { PATH: process.env.PATH, TERM: 'xterm-256color', HOME: `${scratch}/home`, TMPDIR: scratch,
  PI_CODING_AGENT_DIR: `${scratch}/agent`, PI_OFFLINE: '1', TUI: '1', HOOK: hook, KEEP: keep,
  PI_REPRO_HOST: process.env.PI_REPRO_HOST, EVIDENCE_DIR: out,
  ...(process.env.PI_REPRO_COMPACTION ? { PI_REPRO_COMPACTION: process.env.PI_REPRO_COMPACTION } : {}) };
assert(env.PI_REPRO_HOST, 'PI_REPRO_HOST required');
const child = spawn('unshare', ['--user', '--map-root-user', '--net', 'script', '-qefc',
  `stty cols 120 rows 36; exec node '${root}/probe.mjs'`, `${out}/terminal.ansi`], { cwd: scratch, env });
child.stdout.on('data', data => appendFileSync(`${out}/stdout.log`, data));
child.stderr.on('data', data => appendFileSync(`${out}/stderr.log`, data));
const sent = new Set();
const timer = setInterval(() => {
  let events;
  try { events = readFileSync(`${out}/events.jsonl`, 'utf8').trim().split('\n').map(JSON.parse); }
  catch { return; }
  for (const event of events.filter(e => e.type === 'summary_request')) {
    if (sent.has(event.attempt)) continue;
    sent.add(event.attempt);
    appendFileSync(`${out}/driver.jsonl`, JSON.stringify({ action: 'send_escape', afterSeq: event.seq, attempt: event.attempt }) + '\n');
    child.stdin.write('\x1b');
  }
}, 50);
const code = await new Promise((resolve, reject) => { child.on('exit', resolve); child.on('error', reject); });
clearInterval(timer);
assert.equal(code, 0, `PTY process failed; see ${out}`);
const result = verifyEvidence(out);
console.log(JSON.stringify(result));
