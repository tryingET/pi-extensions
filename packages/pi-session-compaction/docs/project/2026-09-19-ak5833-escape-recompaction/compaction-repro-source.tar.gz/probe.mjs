// AK5833 diagnostic only: exact host build + actual custom hook, offline faux inference.
import assert from 'node:assert/strict';
import { appendFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import { provenance, newRunId } from './provenance.mjs';
import minimalHook from './minimal-hook.mjs';

const host = process.env.PI_REPRO_HOST;
assert(host, 'Set PI_REPRO_HOST to the existing built Pi baseline');
const load = (file) => import(pathToFileURL(path.join(host, file)).href);
const sdk = await load('packages/coding-agent/dist/index.js');
const { loadExtensionFromFactory } = await load('packages/coding-agent/dist/core/extensions/loader.js');
const { InMemoryCredentialStore } = await load('packages/ai/dist/index.js');
const { fauxProvider, fauxAssistantMessage, fauxToolCall } = await load('packages/ai/dist/providers/faux.js');
const { createAgentSession, createExtensionRuntime, createEventBus, ModelRuntime, SessionManager, SettingsManager } = sdk;
const { Text } = await load('packages/tui/dist/index.js');
const isTui = process.env.TUI === '1';
const keepRecentTokens = Number(process.env.KEEP ?? 0);
const cancellation = process.env.CANCEL ?? 'attempt';
const hook = process.env.HOOK ?? 'minimal';
assert(['actual', 'minimal'].includes(hook));
assert(['attempt', 'run'].includes(cancellation));
const actualRoot = hook === 'actual' ? process.env.PI_REPRO_COMPACTION : undefined;
assert(hook !== 'actual' || actualRoot, 'Actual hook requires PI_REPRO_COMPACTION package path');
const runId = newRunId();
const inputProvenance = provenance(host, actualRoot);
assert.equal(inputProvenance.hostRef, '4d38031fbdbed43bc481ddf9c3c279005ab24674', 'Use the pinned post-fix baseline');
const dir = process.env.EVIDENCE_DIR;
assert(dir, 'Set EVIDENCE_DIR');
mkdirSync(dir, { recursive: true });
const events = [];
writeFileSync(`${dir}/events.jsonl`, '');
writeFileSync(`${dir}/provenance.json`, JSON.stringify({ runId, ...inputProvenance }, null, 2) + '\n');
const record = (type, details = {}) => {
  const event = { runId, seq: events.length, type, ...details };
  events.push(event);
  appendFileSync(`${dir}/events.jsonl`, JSON.stringify(event) + '\n');
};
record('fixture_start', { hook, keepRecentTokens, cancellation: isTui ? 'escape' : cancellation });
globalThis.fetch = async () => { record('forbidden_fetch'); throw new Error('No network allowed'); };
let session;
let mode;
let tuiRuntime;
if (isTui) process.stdin.on('data', data => {
  if (data.toString() === '\x1b') record('stdin_escape', { attempt: activeCompaction });
});
let activeCompaction = 0;
let attempt = 0;
let answers = 0;
let toolRequests = 0;
let summaries = 0;
let cancellationRequested = false;
const pendingCancels = [];
const faux = fauxProvider({
  models: [{ id: 'repro', name: 'Offline compaction probe', reasoning: false, contextWindow: 32000, maxTokens: 1024 }],
  tokensPerSecond: 1000000,
});
faux.setResponses(Array.from({ length: 12 }, () => async (_context, options) => {
  if (activeCompaction) {
    summaries++;
    record('summary_request', { attempt: activeCompaction, hasSignal: !!options.signal });
    assert(options.signal, 'Real handler must pass a cancellation signal');
    await new Promise((resolve) => {
      const aborted = () => { record('summary_aborted', { attempt: activeCompaction }); resolve(); };
      if (options.signal.aborted) return aborted();
      options.signal.addEventListener('abort', aborted, { once: true });
      if (!isTui && !cancellationRequested) {
        cancellationRequested = true;
        setImmediate(() => {
          record('cancel_requested', { cancellation, attempt: activeCompaction });
          if (cancellation === 'run') pendingCancels.push(session.abort());
          else session.abortCompaction();
        });
      }
    });
    return fauxAssistantMessage('', { stopReason: 'aborted' });
  }
  if (toolRequests++ === 0) {
    record('tool_request');
    return fauxAssistantMessage(fauxToolCall('large_result', {}, { id: 'large-1' }), { stopReason: 'toolUse' });
  }
  answers++;
  record('answer_request');
  return fauxAssistantMessage('Done reading synthetic output.');
}));
const modelRuntime = await ModelRuntime.create({ credentials: new InMemoryCredentialStore(), modelsPath: null,
  allowModelNetwork: false, refreshOnCreate: false });
modelRuntime.registerNativeProvider(faux.provider);
const runtime = createExtensionRuntime();
const eventBus = createEventBus();
const deps = {
  contextProviderApi: {},
  createGitWorktreeProvider: () => ({}),
  runReadOnlyContextProvider: async () => ({ ok: false, verified: false, omissions: [{ reason: 'fixture-isolated' }] }),
  recordFailureTelemetry: async ({ stage, error }) => record('hook_failure', { stage, error: String(error) }),
  recordQualityTelemetry: async (value) => record('hook_quality', value),
};
let factory;
if (actualRoot) {
  const { createSessionCompactionExtension } = await import(pathToFileURL(path.join(actualRoot, 'extensions/session-compaction/registration.js')).href);
  factory = createSessionCompactionExtension({
    enableInputTracking: true, enableSessionBeforeCompact: true, handlerTestsPassed: true,
    noDoubleCompactionPreflight: true, existingCompactionHandlerCount: 0, handlerDeps: deps,
  });
}
const extension = await loadExtensionFromFactory((pi) => {
  const observingPi = Object.create(pi);
  observingPi.on = (name, handler) => pi.on(name, async (event, ctx) => {
    if (name === 'session_before_compact') record('custom_hook_start', {
      attempt, reason: event.reason, keep: event.preparation.settings.keepRecentTokens,
      split: event.preparation.isSplitTurn, historyMessages: event.preparation.messagesToSummarize.length,
      prefixMessages: event.preparation.turnPrefixMessages.length,
    });
    const result = await handler(event, ctx);
    if (name === 'session_before_compact') record('custom_hook_end', { attempt, cancel: result?.cancel === true, summary: !!result?.compaction });
    return result;
  });
  if (hook === 'minimal') minimalHook(observingPi);
  else {
    const registration = factory(observingPi);
    assert(registration.compaction.ok, JSON.stringify(registration));
  }
}, process.cwd(), eventBus, runtime, '<actual-pi-session-compaction>');
const loader = {
  getExtensions: () => ({ extensions: [extension], errors: [], runtime }),
  getSkills: () => ({ skills: [], diagnostics: [] }), getPrompts: () => ({ prompts: [], diagnostics: [] }),
  getThemes: () => ({ themes: [], diagnostics: [] }), getAgentsFiles: () => ({ agentsFiles: [] }),
  getSystemPrompt: () => 'Offline compaction probe.', getSystemPromptSource: () => undefined,
  getAppendSystemPrompt: () => [], getAppendSystemPromptSources: () => [], extendResources() {}, async reload() {},
};
const settingsManager = SettingsManager.inMemory({ compaction: { enabled: true, reserveTokens: 15000, keepRecentTokens }, retry: { enabled: false } });
({ session } = await createAgentSession({ cwd: process.cwd(), agentDir: process.env.PI_CODING_AGENT_DIR,
  modelRuntime, model: faux.getModel(), resourceLoader: loader, settingsManager, eventBus,
  sessionManager: SessionManager.inMemory(process.cwd()), thinkingLevel: 'off', tools: ['large_result'],
  customTools: [{ name: 'large_result', label: 'Large result', description: 'Synthetic context pressure',
    parameters: { type: 'object', properties: {}, additionalProperties: false },
    execute: async () => ({ content: [{ type: 'text', text: 'x'.repeat(80000) }], details: {} }),
    renderResult: () => new Text('Synthetic tool returned 80000 bytes (display elided)', 0, 0),
  }],
}));
session.subscribe((event) => {
  if (event.type === 'message_update') return;
  record(event.type, { reason: event.reason, aborted: event.aborted, role: event.message?.role,
    stopReason: event.message?.stopReason, errorMessage: event.message?.errorMessage ?? event.errorMessage });
  if (event.type === 'compaction_start') {
    activeCompaction = ++attempt;
    cancellationRequested = false;
    assert(attempt <= 3, 'Bounded diagnostic encountered more than three compactions');
  }
  if (event.type === 'compaction_end') activeCompaction = 0;
});
const watchdog = setTimeout(() => { console.error('Probe watchdog expired'); writeFileSync(`${dir}/events.json`, JSON.stringify(events, null, 2)); process.exit(2); }, 15000);
try {
  if (isTui) {
    assert(process.stdin.isTTY && process.stdout.isTTY, 'TUI probe needs a real PTY');
    const settled = new Promise(resolve => session.subscribe(event => {
      if (event.type === 'agent_settled') resolve();
    }));
    tuiRuntime = new sdk.AgentSessionRuntime(session, { cwd: process.cwd(), agentDir: process.env.PI_CODING_AGENT_DIR },
      async () => { throw new Error('Session replacement not allowed'); });
    mode = new sdk.InteractiveMode(tuiRuntime, { initialMessage: 'Read large_result then give a short answer.', tuiMode: 'inline' });
    await mode.init();
    void mode.run();
    await settled;
  } else {
    await session.bindExtensions({ mode: 'print' });
    await session.prompt('Read large_result then give a short answer.');
  }
  await Promise.all(pendingCancels);
  await session.waitForIdle();
  assert.deepEqual(provenance(host, actualRoot), inputProvenance, 'Source/build inputs changed during run');
  const result = { runId, hook, keepRecentTokens, cancellation: isTui ? 'escape' : cancellation,
    escapes: events.filter(e => e.type === 'stdin_escape').length, attempts: attempt, summaries, answers,
    compactionEntries: session.sessionManager.getEntries().filter(e => e.type === 'compaction').length,
    hookFailures: events.filter(e => e.type === 'hook_failure'),
    assistantErrors: events.filter(e => e.type === 'message_end' && ['error', 'aborted'].includes(e.stopReason)),
    forbiddenFetches: events.filter(e => e.type === 'forbidden_fetch').length,
    idle: !session.isStreaming, autoCompactionEnabled: settingsManager.getCompactionSettings(faux.getModel()).enabled,
  };
  writeFileSync(`${dir}/events.json`, JSON.stringify(events, null, 2) + '\n');
  writeFileSync(`${dir}/result.json`, JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
} finally {
  clearTimeout(watchdog);
  mode?.stop();
  if (tuiRuntime) await tuiRuntime.dispose();
  else session.dispose();
}
if (isTui) process.exit(0);
